package contact;

public class ContractService {

}
